#!/bin/sh
while true
do
#Perintah menampilkan ukuran memory pada sistem dalam satuan megabytes
echo "Menampilkan ukuran memori pada system...."
free --mega
sleep 3s
[:space:]
#Perintah menampilkan penggunaan ruang disk pada filesystem dalam satuan gigabytes
echo "Menampilkan penggunaan ruang disk pada filesystem...."
df -BG
sleep 3s

#Menampilkan penggunaan ruang disk pada filesystem hanya untuk kolom Filesystem dan Use% (ditampilkan juga nama kolomnya) serta tanpa menyertakan tmpfs
echo "Menampilkan penggunaan ruang disk filesystem dan Use%...."
df -h | awk '!/tmpfs/ {print $1"  "$5}'
sleep 1m
done
